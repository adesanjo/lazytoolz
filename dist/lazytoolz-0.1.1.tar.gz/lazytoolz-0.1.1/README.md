# Lazy programming for Python

```
pip install lazytools
```

This package adds lazily evaluated constructs.