from .lazylist import LazyList

__version__ = "0.1.5"
