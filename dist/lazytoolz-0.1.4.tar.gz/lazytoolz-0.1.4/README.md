# Lazy programming for Python

```
pip install lazytools
```

This package adds lazily evaluated immutable objects.

```python
from lazytoolz import LazyList
```